package com.oxymoron.ui.list.recyclerview;

import com.oxymoron.ui.list.data.RestaurantThumbnail;

public interface OnClickListener {
    void onClick(RestaurantThumbnail thumbnail);
}
