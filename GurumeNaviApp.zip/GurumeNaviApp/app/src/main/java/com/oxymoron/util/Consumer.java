package com.oxymoron.util;

public interface Consumer<T> {
    public void accept(T value);
}
