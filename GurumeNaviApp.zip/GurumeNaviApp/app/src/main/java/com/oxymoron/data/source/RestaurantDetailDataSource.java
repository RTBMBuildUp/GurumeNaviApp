package com.oxymoron.data.source;

public interface RestaurantDetailDataSource {
    public void saveRestaurantDetail();


}
