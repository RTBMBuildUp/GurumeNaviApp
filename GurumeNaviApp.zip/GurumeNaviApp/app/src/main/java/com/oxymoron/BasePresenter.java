package com.oxymoron;

public interface BasePresenter {
    void start();
}
