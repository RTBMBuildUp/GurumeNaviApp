package com.oxymoron.util;

public interface Function<T, R> {
    public R apply(T value);
}