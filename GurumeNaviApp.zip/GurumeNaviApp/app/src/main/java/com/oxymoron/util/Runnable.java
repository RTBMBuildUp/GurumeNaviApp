package com.oxymoron.util;

public interface Runnable {
    void run();
}
